<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\DB;

class UsuariosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        $usuarios = [
            ['nombre' => 'Gabriel', 'email' => 'gabriel@gmail.com', 'password' => '123', 'apellido' => 'neves', 'nick' => 'gabi', 'role' => 'usuario','fecha_nascimiento' => '06-07-2003', 'dni' => '54988059g'],
            ['nombre' => 'Admin', 'email' => 'admin@gmail.com', 'password' => '123', 'apellido' => 'admin', 'nick' => 'ad', 'role' => 'administrador','fecha_nascimiento' => '06-01-2007', 'dni' => '52450759f'],
            // Agrega más registros según sea necesario
        ];

        DB::table('users')->insert($usuarios);
    }
}
