<?php

// database/seeders/CategoriasTableSeeder.php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategoriasTableSeeder extends Seeder
{
    public function run()
    {
        // Puedes ajustar la cantidad de registros según tus necesidades
        $categorias = [
            ['nombre' => 'Electrónicos', 'descripcion' => 'Categoría de productos electrónicos'],
            ['nombre' => 'Ropa', 'descripcion' => 'Categoría de ropa'],
            // Agrega más registros según sea necesario
        ];

        DB::table('categorias')->insert($categorias);
    }
}

