<!-- crearCategoria.blade.php -->

@extends('layouts.app')

@section('content')
    <h1>Crear Nueva Categoría</h1>

    <form action="{{ route('admin.categorias.store') }}" method="post">
        @csrf
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br>

        <label for="descripcion">Descripción:</label>
        <textarea id="descripcion" name="descripcion"></textarea>
        <br>

        <button type="submit">Crear Categoría</button>
    </form>

    <a href="{{ route('admin.categorias.index') }}">Volver al Listado de Categorías</a>
@endsection
