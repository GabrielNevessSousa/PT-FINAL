<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú de Administrador</title>
</head>
<body>
    <h1>Bienvenido al Menú de Administrador</h1>

    <!-- Botón para mostrar productos -->
    <a href="{{ route('admin.productos.index') }}">
        <button>Mostrar Productos</button>
    </a>

    <!-- Botón para volver -->
    <a href="{{ route('admin.menuAdmin') }}">
        <button>Volver</button>
    </a>

</body>
</html>
