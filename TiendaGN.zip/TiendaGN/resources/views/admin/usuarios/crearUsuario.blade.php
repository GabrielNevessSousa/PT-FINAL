<!-- En tu vista para crear usuarios (admin.usuarios.crearUsuario.blade.php) -->
@extends('layouts.app')

@section('content')
    <h1>Crear Nuevo Usuario</h1>

    @if($errors->any())
        <div>
            <strong>Error:</strong>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.usuarios.store') }}" method="post">
        @csrf

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="{{ old('nombre') }}" required><br>

        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" value="{{ old('apellido') }}" required><br>

        <label for="nick">Nick:</label>
        <input type="text" id="nick" name="nick" value="{{ old('nick') }}" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="{{ old('email') }}" required><br>

        <label for="fecha_nascimiento">Fecha nascimiento:</label>
        <input type="date" id="fecha_nascimiento" name="fecha_nascimiento" value="{{ old('fecha_nascimiento') }}" required><br>

        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" value="{{ old('fecha_nascidnimiento') }}" required><br>

        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required>

        <label for="role">Rol:</label>
        <select id="role" name="role" required>
            <option value="usuario" @if(old('role') === 'usuario') selected @endif>Usuario</option>
            <option value="administrador" @if(old('role') === 'administrador') selected @endif>Administrador</option>
        </select><br>

        <button type="submit">Crear Usuario</button><br>
    </form>

    <!-- Botón para volver al listado de usuarios -->
    <a href="{{ route('admin.usuarios.index') }}">
        <button>Volver al Listado</button>
    </a>
@endsection
