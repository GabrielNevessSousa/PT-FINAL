<!-- En tu vista para mostrar usuarios (admin.usuarios.mostrar.blade.php) -->
@extends('layouts.app')

@section('content')
    <h1>Listado de Usuarios</h1>

    @if($usuarios->isEmpty())
        <p>No hay usuarios disponibles.</p>
    @else
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Contraseña</th>
                    <th>Nick</th>
                    <th>Email</th>
                    <th>DNI</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach($usuarios as $usuario)
                    <tr>
                        <td>{{ $usuario->id }}</td>
                        <td>{{ $usuario->nombre }}</td>
                        <td>{{ $usuario->apellido }}</td>
                        <td>{{ $usuario->password }}</td>
                        <td>{{ $usuario->nick }}</td>
                        <td>{{ $usuario->email }}</td>
                        <td>{{ $usuario->dni }}</td>
                        <td>{{ $usuario->role }}</td>
                        <td>
                            <form action="{{ route('admin.usuarios.destroy', ['id' => $usuario->id]) }}" method="post">
                                @csrf
                                @method('delete')
                                <button type="submit">Eliminar</button>
                            </form>
                            <!-- Botón para editar -->
                            <a href="{{ route('admin.usuarios.edit', ['id' => $usuario->id]) }}">Editar</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <!-- Botón para volver al menú de usuarios -->
        <a href="{{ route('admin.usuarios.menu') }}">
            <button>Volver</button>
        </a>

        <!-- Botón para crear nuevo usuario -->
        <a href="{{ route('admin.usuarios.create') }}">
            <button>Crear</button>
        </a>
    @endif
@endsection
