<!-- En tu vista para editar usuarios (admin.usuarios.editarUsuario.blade.php) -->
@extends('layouts.app')

@section('content')
    <h1>Editar Usuario</h1>

    @if($errors->any())
        <div>
            <strong>Error:</strong>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.usuarios.update', ['id' => $usuario->id]) }}" method="post">
        @csrf
        @method('put')

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="{{ $usuario->nombre }}" ><br>

        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" value="{{ $usuario->apellido }}" ><br>


        <label for="nick">Nick:</label>
        <input type="text" id="nick" name="nick" value="{{ $usuario->nick }}" required><br>


        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="{{ $usuario->email }}" required><br>

        <label for="contrasena">Contrasena:</label>
        <input type="text" id="contrasena" name="contrasena" value="{{ $usuario->password }}" required><br>

        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" value="{{ $usuario->dni }}" required><br>

        <label for="role">Rol:</label>
        <select id="role" name="role" required>
            <option value="usuario" @if($usuario->role === 'usuario') selected @endif>Usuario</option>
            <option value="administrador" @if($usuario->role === 'administrador') selected @endif>Administrador</option>
        </select><br>


        <button type="submit">Guardar Cambios</button><br>

    </form>

    <!-- Botón para volver al listado de usuarios -->
    <a href="{{ route('admin.usuarios.index') }}">
        <button>Volver al Listado</button>
    </a>
    
@endsection
