<!-- resources/views/menuUser/editar-perfil.blade.php -->

@extends('layouts.app')

@section('content')
    <h1>Editar Perfil</h1>

    <form method="POST" action="{{ route('perfil.update') }}">
        @csrf
        @method('PUT')

        <label for="nick">Nick:</label>
        <input type="text" id="nick" name="nick" value="{{ old('nick', $usuario->nick) }}" required>
        <br>

        <label for="email">Correo Electrónico:</label>
        <input type="email" id="email" name="email" value="{{ old('email', $usuario->email) }}" required>
        <br>

        <button type="submit">Guardar Cambios</button>
    </form>
@endsection
