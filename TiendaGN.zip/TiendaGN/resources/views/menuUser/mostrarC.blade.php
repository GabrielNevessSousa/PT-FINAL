<!-- resources/views/menuUser/mostrarC.blade.php -->

@extends('layouts.app')

@section('content')

<h1>Listado de Categorías</h1>

@if($categorias->isEmpty())
    <p>No hay categorías disponibles.</p>
@else

    <!-- Tabla de categorías -->
    <table border="1">
        <!-- Encabezados de la tabla -->
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
            </tr>
        </thead>
        <tbody>
            <!-- Contenido de la tabla -->
            @foreach($categorias as $categoria)
                <tr>
                    <td>{{ $categoria->id_categoria }}</td>
                    <td>{{ $categoria->nombre }}</td>
                    <td>{{ $categoria->descripcion }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Botón para volver -->
    <a href="{{ route('menuUser.pagPrincipal') }}">
        <button>Volver a la Página Principal</button>
    </a>
@endif

<!-- Agrega botones u opciones adicionales según sea necesario -->

@endsection
