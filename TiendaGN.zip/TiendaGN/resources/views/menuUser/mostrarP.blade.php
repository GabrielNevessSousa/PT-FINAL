<!-- resources/views/menuUser/mostrarP.blade.php -->

@extends('layouts.app')

@section('content')

<h1>Listado de Productos</h1>

@if($productos->isEmpty())
    <p>No hay productos disponibles.</p>
@else

    <!-- Opciones de orden -->
    <form action="{{ route('menuUser.mostrarP') }}" method="get">
        @csrf
        <label for="orden">Ordenar por Precio:</label>
        <select name="orden" id="orden">
            <option value="asc" @if(request('orden') == 'asc') selected @endif>De menor a mayor</option>
            <option value="desc" @if(request('orden') == 'desc') selected @endif>De mayor a menor</option>
        </select>
        <button type="submit">Aplicar</button>
    </form>

    <!-- Tabla de productos -->
    <table border="1">
        <!-- Encabezados de la tabla -->
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Unidades</th>
                <th>Categoria</th>
                <th>Precio</th>
            </tr>
        </thead>
        <tbody>
            <!-- Contenido de la tabla -->
            @foreach($productos as $producto)
                <tr>
                    <td>{{ $producto->id_producto }}</td>
                    <td>{{ $producto->nombre }}</td>
                    <td>{{ $producto->descripcion }}</td>
                    <td>{{ $producto->unidades }}</td>
                    <td>{{ $producto->categoria }}</td>
                    <td>{{ $producto->precio_unitario }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Botón para volver -->
    <a href="{{ route('menuUser.pagPrincipal') }}">
        <button>Volver a la Página Principal</button>
    </a>
@endif

<!-- Agrega botones u opciones adicionales según sea necesario -->

@endsection
