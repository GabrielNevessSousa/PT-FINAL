<!-- resources/views/welcome.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido</title>
</head>
<body>
    <h1>Hola Usuario</h1>

    <a href="{{ route('perfil.index') }}"> <!-- Asegúrate de tener la ruta correcta para el perfil -->
        <button>Mi perfil</button>
    </a>

    <a href="{{ route('menuUser.mostrarP') }}"> <!-- Asegúrate de tener la ruta correcta para ver productos -->
        <button>Ver Productos</button>
    </a>

    <a href="{{ route('menuUser.mostrarC') }}"> <!-- Asegúrate de tener la ruta correcta para ver productos -->
        <button>Ver Categorias</button>
    </a>

    <form action="{{ route('logout') }}" method="post">
        @csrf
        <button type="submit">Logout</button>
    </form>

</body>
</html>
