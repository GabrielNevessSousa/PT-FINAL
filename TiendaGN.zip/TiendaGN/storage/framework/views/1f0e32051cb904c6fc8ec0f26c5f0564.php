<!-- crearCategoria.blade.php -->



<?php $__env->startSection('content'); ?>
    <h1>Crear Nueva Categoría</h1>

    <form action="<?php echo e(route('admin.categorias.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br>

        <label for="descripcion">Descripción:</label>
        <textarea id="descripcion" name="descripcion"></textarea>
        <br>

        <button type="submit">Crear Categoría</button>
    </form>

    <a href="<?php echo e(route('admin.categorias.index')); ?>">Volver al Listado de Categorías</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TiendaGX\resources\views/admin/categorias/crearCategoria.blade.php ENDPATH**/ ?>