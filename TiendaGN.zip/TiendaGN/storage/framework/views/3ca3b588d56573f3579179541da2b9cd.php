<!-- resources/views/menuUser/mostrarP.blade.php -->



<?php $__env->startSection('content'); ?>

<h1>Listado de Productos</h1>

<?php if($productos->isEmpty()): ?>
    <p>No hay productos disponibles.</p>
<?php else: ?>

    <!-- Opciones de orden -->
    <form action="<?php echo e(route('menuUser.mostrarP')); ?>" method="get">
        <?php echo csrf_field(); ?>
        <label for="orden">Ordenar por Precio:</label>
        <select name="orden" id="orden">
            <option value="asc" <?php if(request('orden') == 'asc'): ?> selected <?php endif; ?>>De menor a mayor</option>
            <option value="desc" <?php if(request('orden') == 'desc'): ?> selected <?php endif; ?>>De mayor a menor</option>
        </select>
        <button type="submit">Aplicar</button>
    </form>

    <!-- Tabla de productos -->
    <table border="1">
        <!-- Encabezados de la tabla -->
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Unidades</th>
                <th>Categoria</th>
                <th>Precio</th>
            </tr>
        </thead>
        <tbody>
            <!-- Contenido de la tabla -->
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->id_producto); ?></td>
                    <td><?php echo e($producto->nombre); ?></td>
                    <td><?php echo e($producto->descripcion); ?></td>
                    <td><?php echo e($producto->unidades); ?></td>
                    <td><?php echo e($producto->categoria); ?></td>
                    <td><?php echo e($producto->precio_unitario); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Botón para volver -->
    <a href="<?php echo e(route('menuUser.pagPrincipal')); ?>">
        <button>Volver a la Página Principal</button>
    </a>
<?php endif; ?>

<!-- Agrega botones u opciones adicionales según sea necesario -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TiendaGN\resources\views/menuUser/mostrarP.blade.php ENDPATH**/ ?>