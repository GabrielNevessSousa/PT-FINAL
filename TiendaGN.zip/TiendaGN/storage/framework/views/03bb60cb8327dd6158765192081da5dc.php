<!-- En tu vista para mostrar usuarios (admin.usuarios.mostrar.blade.php) -->


<?php $__env->startSection('content'); ?>
    <h1>Listado de Usuarios</h1>

    <?php if($usuarios->isEmpty()): ?>
        <p>No hay usuarios disponibles.</p>
    <?php else: ?>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Nick</th>
                    <th>Email</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($usuario->id); ?></td>
                        <td><?php echo e($usuario->nombre); ?></td>
                        <td><?php echo e($usuario->apellido); ?></td>
                        <td><?php echo e($usuario->nick); ?></td>
                        <td><?php echo e($usuario->email); ?></td>
                        <td><?php echo e($usuario->role); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.usuarios.destroy', ['id' => $usuario->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit">Eliminar</button>
                            </form>
                            <!-- Botón para editar -->
                            <a href="<?php echo e(route('admin.usuarios.edit', ['id' => $usuario->id])); ?>">Editar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Botón para volver al menú de usuarios -->
        <a href="<?php echo e(route('admin.usuarios.menu')); ?>">
            <button>Volver</button>
        </a>

        <!-- Botón para crear nuevo usuario -->
        <a href="<?php echo e(route('admin.usuarios.create')); ?>">
            <button>Crear</button>
        </a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TiendaG\resources\views/admin/usuarios/mostrar.blade.php ENDPATH**/ ?>