<!-- En tu vista para editar usuarios (admin.usuarios.editarUsuario.blade.php) -->


<?php $__env->startSection('content'); ?>
    <h1>Editar Usuario</h1>

    <?php if($errors->any()): ?>
        <div>
            <strong>Error:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.usuarios.update', ['id' => $usuario->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo e($usuario->nombre); ?>" >

        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" value="<?php echo e($usuario->apellido); ?>" >

        <label for="nick">Nick:</label>
        <input type="text" id="nick" name="nick" value="<?php echo e($usuario->nick); ?>" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo e($usuario->email); ?>" required>

        <label for="role">Rol:</label>
        <select id="role" name="role" required>
            <option value="usuario" <?php if($usuario->role === 'usuario'): ?> selected <?php endif; ?>>Usuario</option>
            <option value="administrador" <?php if($usuario->role === 'administrador'): ?> selected <?php endif; ?>>Administrador</option>
        </select>

        <button type="submit">Guardar Cambios</button>
    </form>

    <!-- Botón para volver al listado de usuarios -->
    <a href="<?php echo e(route('admin.usuarios.index')); ?>">
        <button>Volver al Listado</button>
    </a>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TiendaG\resources\views/admin/usuarios/editarUsuario.blade.php ENDPATH**/ ?>