<!-- En tu vista para mostrar categorías (admin.categorias.show.blade.php) -->


<?php $__env->startSection('content'); ?>
    <h1>Listado de Categorías</h1>

    <?php if($categorias->isEmpty()): ?>
        <p>No hay categorías disponibles.</p>
    <?php else: ?>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($categoria->id_categoria); ?></td>
                        <td><?php echo e($categoria->nombre); ?></td>
                        <td><?php echo e($categoria->descripcion); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.categorias.destroy', ['id' => $categoria->id_categoria])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit">Eliminar</button>
                            </form>
                            <!-- Botón para editar -->
                            <a href="<?php echo e(route('admin.categorias.edit', ['id' => $categoria->id_categoria])); ?>">Editar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Botón para volver al menú de categorías -->
        <a href="<?php echo e(route('admin.categorias.menu')); ?>">
            <button>Volver</button>
        </a>

        <!-- Botón para crear nueva categoría -->
        <a href="<?php echo e(route('admin.categorias.create')); ?>">
            <button>Crear</button>
        </a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TiendaG\resources\views/admin/categorias/mostrar.blade.php ENDPATH**/ ?>