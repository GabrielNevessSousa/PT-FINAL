<!-- resources/views/menuUser/perfil.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil del Usuario</title>
</head>
<body>
    <h1>Perfil del Usuario</h1>

    <?php if(auth()->guard()->check()): ?>
        <p>Bienvenido, <?php echo e(auth()->user()->nombre); ?></p>
        <p>Correo Electrónico: <?php echo e(auth()->user()->email); ?></p>
        <p>Rol: <?php echo e(auth()->user()->role); ?></p>

        <!-- Agregar enlace para editar el perfil -->
        <a href="<?php echo e(route('perfil.edit')); ?>">Editar Perfil</a>
    <?php else: ?>
        <p>No estás autenticado.</p>
    <?php endif; ?>

    <!-- Agrega el botón de logout si estás utilizando un formulario -->
  
</body>
</html>
<?php /**PATH C:\xampp\htdocs\TiendaG\resources\views/menuUser/perfil.blade.php ENDPATH**/ ?>