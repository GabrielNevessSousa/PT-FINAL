<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Producto</title>
</head>
<body>
    <h1>Editar Producto</h1>

    <form action="<?php echo e(route('admin.productos.update', ['id' => $producto->id_producto])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" value="<?php echo e($producto->nombre); ?>" required>

        <label for="descripcion">Descripción:</label>
        <textarea name="descripcion"><?php echo e($producto->descripcion); ?></textarea>

        <label for="precio_unitario">Precio Unitario:</label>
        <input type="number" name="precio_unitario" min="0" step="0.01" value="<?php echo e($producto->precio_unitario); ?>" required>

        <label for="categoria">Categoría:</label>
        <input type="text" name="categoria" value="<?php echo e($producto->categoria); ?>" required>

        <label for="unidades">Unidades:</label>
        <input type="number" name="unidades" min="0" value="<?php echo e($producto->unidades); ?>" required>

        <!-- Agrega más campos según sea necesario -->

        <button type="submit">Actualizar Producto</button>
    </form>

    <a href="<?php echo e(route('admin.productos.index')); ?>">
        <button>Volver al Menú de Productos</button>
    </a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\TiendaGX\resources\views/admin/productos/editarProducto.blade.php ENDPATH**/ ?>