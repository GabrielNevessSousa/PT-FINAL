<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
</head>
<body>
    <h1>Iniciar Sesión</h1>
     
    <form method="POST" action="<?php echo e(url('/login')); ?>">
        <?php echo csrf_field(); ?> 
        <!-- Campos de inicio de sesión -->
        <label for="email">Email:</label>
        <input type="text" id="email" name="email" autocomplete="email" required>
        <br>
    
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" autocomplete="current-password" required>
        <br>

        <!-- Botón de inicio de sesión -->
        <button type="submit">Iniciar Sesión</button>
    </form>

    <!-- Enlace directo a la página de registro -->
    <a href="<?php echo e(route('register.index')); ?>">Registrarte</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Tienda\resources\views/login/login.blade.php ENDPATH**/ ?>