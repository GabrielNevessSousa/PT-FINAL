<!-- resources/views/menuUser/mostrarC.blade.php -->



<?php $__env->startSection('content'); ?>

<h1>Listado de Categorías</h1>

<?php if($categorias->isEmpty()): ?>
    <p>No hay categorías disponibles.</p>
<?php else: ?>

    <!-- Tabla de categorías -->
    <table border="1">
        <!-- Encabezados de la tabla -->
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
            </tr>
        </thead>
        <tbody>
            <!-- Contenido de la tabla -->
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($categoria->id_categoria); ?></td>
                    <td><?php echo e($categoria->nombre); ?></td>
                    <td><?php echo e($categoria->descripcion); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Botón para volver -->
    <a href="<?php echo e(route('menuUser.pagPrincipal')); ?>">
        <button>Volver a la Página Principal</button>
    </a>
<?php endif; ?>

<!-- Agrega botones u opciones adicionales según sea necesario -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TiendaGX\resources\views/menuUser/mostrarC.blade.php ENDPATH**/ ?>