<!-- En tu vista para mostrar productos (admin.productos.show.blade.php) -->


<?php $__env->startSection('content'); ?>
    <h1>Listado de Productos</h1>

    <?php if($productos->isEmpty()): ?>
        <p>No hay productos disponibles.</p>
    <?php else: ?>
        <!-- Menú desplegable para ordenar por precio -->
<form action="<?php echo e(route('admin.productos.index')); ?>" method="get">
    <?php echo csrf_field(); ?>
    <label for="orden">Ordenar por Precio:</label>
    <select name="orden" id="orden">
        <option value="asc">De menor a mayor</option>
        <option value="desc">De mayor a menor</option>
    </select>
    <button type="submit">Aplicar</button>
</form>

<!-- Tabla de productos -->
<table border="1">
    <!-- Encabezados de la tabla -->
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Precio</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <!-- Contenido de la tabla -->
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($producto->id_producto); ?></td>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td><?php echo e($producto->precio_unitario); ?></td>
                <td>
                    <!-- Botón para editar -->
                    <a href="<?php echo e(route('admin.productos.edit', ['id' => $producto->id_producto])); ?>">Editar</a>
                    
                    <!-- Formulario para eliminar -->
                    <form action="<?php echo e(route('admin.productos.destroy', ['id' => $producto->id_producto])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


        <!-- Botón para volver al menú de administrador de productos -->
        <a href="<?php echo e(route('admin.productos.menu')); ?>">
            <button>Volver al Menú de Productos</button>
        </a>

        <!-- Botón para crear nuevo producto -->
        <a href="<?php echo e(route('admin.productos.create')); ?>">
            <button>Crear Nuevo Producto</button>
        </a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TiendaG\resources\views/admin/productos/mostrar.blade.php ENDPATH**/ ?>