<!-- resources/views/menuUser/editar-perfil.blade.php -->



<?php $__env->startSection('content'); ?>
    <h1>Editar Perfil</h1>

    <form method="POST" action="<?php echo e(route('perfil.update')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label for="nick">Nick:</label>
        <input type="text" id="nick" name="nick" value="<?php echo e(old('nick', $usuario->nick)); ?>" required>
        <br>

        <label for="email">Correo Electrónico:</label>
        <input type="email" id="email" name="email" value="<?php echo e(old('email', $usuario->email)); ?>" required>
        <br>

        <button type="submit">Guardar Cambios</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TiendaGX\resources\views/menuUser/editar-perfil.blade.php ENDPATH**/ ?>