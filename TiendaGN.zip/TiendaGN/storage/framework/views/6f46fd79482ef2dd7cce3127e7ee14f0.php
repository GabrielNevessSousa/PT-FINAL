<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú de Administrador</title>
</head>
<body>
    <h1>Bienvenido al Menú de Administrador</h1>

    <!-- Botón para mostrar productos -->
    <a href="<?php echo e(route('admin.usuarios.index')); ?>">
        <button>Mostrar Usuarios</button>
    </a>

    <!-- Botón para volver -->
    <a href="<?php echo e(route('admin.menuAdmin')); ?>">
        <button>Volver</button>
    </a>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\TiendaGN\resources\views/admin/usuarios/menuUsuario.blade.php ENDPATH**/ ?>