<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú de Categorías</title>
</head>
<body>
    <h1>Bienvenido al Menú de Categorías</h1>


    <a href="<?php echo e(route('admin.categorias.index')); ?>">
    <button>Mostrar Categorías</button>
</a>

<!-- Botón para volver al menú de administrador -->
<a href="<?php echo e(route('admin.menuAdmin')); ?>">
    <button>Volver al Menú de Administrador</button>
</a>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\TiendaGN\resources\views/admin/categorias/menuCategoria.blade.php ENDPATH**/ ?>