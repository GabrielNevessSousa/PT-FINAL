<?php

use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\HolaController;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\PerfilController;
use Illuminate\Support\Facades\Route;

// Ruta principal de la aplicación
Route::get('/', function () {
    return view('welcome');
});

// Rutas de autenticación
Route::get('/login', [LoginController::class, 'index'])->name('login.index');
Route::post('/login', [LoginController::class, 'authenticate']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
Route::get('/register', [RegisterController::class, 'index'])->name('register.index');
Route::post('/register', [RegisterController::class, 'store'])->name('register.store');
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');

// Rutas autenticadas
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [LoginController::class, 'dashboard'])->name('dashboard');

    // Rutas para el rol 'usuario'
    Route::middleware(['role:usuario'])->group(function () {
        Route::get('/menuUser', [LoginController::class, 'index'])->name('menuUser.index');
        Route::get('/menuUser/mostrarP', [ProductoController::class, 'indexUsuario'])->name('menuUser.mostrarP');
        Route::get('/menuUser/mostrarC', [HolaController::class, 'indexUsuario'])->name('menuUser.mostrarC');
    });

    // Rutas para el rol 'administrador'
    Route::middleware(['role:administrador'])->group(function () {
        Route::get('/admin/menuAdmin', function () {
            return view('admin.menuAdmin');
        })->name('admin.menuAdmin');

        // Rutas para productos en la carpeta admin/productos
        Route::prefix('/admin/productos')->group(function () {
            Route::get('/menu', function () {
                return view('admin.productos.menuProducto');
            })->name('admin.productos.menu');
            
            Route::get('/', [ProductoController::class, 'index'])->name('admin.productos.index');
            Route::get('/create', [ProductoController::class, 'create'])->name('admin.productos.create');
            Route::post('/store', [ProductoController::class, 'store'])->name('admin.productos.store');
            Route::get('/show/{id}', [ProductoController::class, 'show'])->name('admin.productos.show');
            Route::get('/edit/{id}', [ProductoController::class, 'edit'])->name('admin.productos.edit');
            Route::delete('/destroy/{id}', [ProductoController::class, 'destroy'])->name('admin.productos.destroy');
            Route::put('/update/{id}', [ProductoController::class, 'update'])->name('admin.productos.update');
        });

        // Rutas para categorías en la carpeta admin/categorias
        Route::prefix('/admin/categorias')->group(function () {
            Route::get('/menu', function () {
                return view('admin.categorias.menuCategoria');
            })->name('admin.categorias.menu');

            Route::get('/', [HolaController::class, 'index'])->name('admin.categorias.index');
            Route::get('/create', [HolaController::class, 'create'])->name('admin.categorias.create');
            Route::post('/store', [HolaController::class, 'store'])->name('admin.categorias.store');
            Route::get('/show/{id}', [HolaController::class, 'show'])->name('admin.categorias.show');
            Route::get('/edit/{id}', [HolaController::class, 'edit'])->name('admin.categorias.edit');
            Route::delete('/destroy/{id}', [HolaController::class, 'destroy'])->name('admin.categorias.destroy');
            Route::put('/update/{id}', [HolaController::class, 'update'])->name('admin.categorias.update');
        });

        // Rutas para usuarios en la carpeta admin/usuarios
        Route::prefix('/admin/usuarios')->group(function () {
            Route::get('/menu', function () {
                return view('admin.usuarios.menuUsuario');
            })->name('admin.usuarios.menu');

            Route::get('/', [UsuarioController::class, 'index'])->name('admin.usuarios.index');
            Route::get('/create', [UsuarioController::class, 'create'])->name('admin.usuarios.create');
            Route::post('/store', [UsuarioController::class, 'store'])->name('admin.usuarios.store');
            Route::get('/show/{id}', [UsuarioController::class, 'show'])->name('admin.usuarios.show');
            Route::get('/edit/{id}', [UsuarioController::class, 'edit'])->name('admin.usuarios.edit');
            Route::delete('/destroy/{id}', [UsuarioController::class, 'destroy'])->name('admin.usuarios.destroy');
            Route::put('/update/{id}', [UsuarioController::class, 'update'])->name('admin.usuarios.update');
        });
    });
});

// Rutas Usuario perfil
Route::get('/menuUser/pagPrincipal', function () {
    return view('menuUser.pagPrincipal');
})->name('menuUser.pagPrincipal');

Route::get('/perfil', [PerfilController::class, 'index'])->name('perfil.index');
Route::get('/perfil/editar', [PerfilController::class, 'edit'])->name('perfil.edit');
Route::put('/perfil/editar', [PerfilController::class, 'update'])->name('perfil.update');

?>