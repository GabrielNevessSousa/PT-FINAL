<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class LoginModel extends Authenticatable
{

    use Notifiable, HasFactory;

//Clase para comprobar la tabla a la que se ejecuta
   
  
}
