<?php
// app/Http/Controllers/PerfilController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PerfilController extends Controller
{
    public function index()
    {
        $usuario = Auth::user();
        return view('menuUser.perfil', compact('usuario'));
    }

    public function edit()
    {
        $usuario = Auth::user();
        return view('menuUser.editar-perfil', compact('usuario'));
    }

    public function update(Request $request)
    {
        $usuario = Auth::user();

        $request->validate([
           
            'email' => 'required|email|unique:users,email,' . $usuario->id,
            'nick' => 'required|string|max:255',
        ]);

        $usuario->update([
           
            'email' => $request->input('email'),
            'nick' => $request->input('nick'),
        ]);

        return redirect()->route('perfil.index')->with('success', 'Perfil actualizado exitosamente.');
    }
}
