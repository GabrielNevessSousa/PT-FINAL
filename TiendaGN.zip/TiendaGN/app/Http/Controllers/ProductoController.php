<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProductoModel; // Asegúrate de importar el modelo User si no lo has hecho

class ProductoController extends Controller
{
    public function index(Request $request)
    {
        // Obtener todos los productos desde la base de datos
        $query = ProductoModel::query();

   
        if ($request->has('orden')) {
            $orden = $request->input('orden');
            $query->orderBy('precio_unitario', $orden);
        } else {
            // Si no se ha seleccionado orden, mostrar desordenado
            $query->inRandomOrder();
        }

        // Ejecutar la consulta y obtener los productos
        $productos = $query->get();

        // Retornar la vista con los productos y categorías
        return view('admin.productos.mostrar', [
            'productos' => $productos,
           
        ]);
    }

    public function indexUsuario()
    {
        // Obtener todos los productos desde la base de datos (puedes ajustar esto según las necesidades del usuario)
        $query = ProductoModel::query();
    
        if (request()->has('orden')) {
            $orden = request()->input('orden');
            $query->orderBy('precio_unitario', $orden);
        } else {
            // Si no se ha seleccionado orden, mostrar desordenado
            $query->inRandomOrder();
        }
    
        // Ejecutar la consulta y obtener los productos
        $productos = $query->get();
    
        // Retornar la vista con los productos y categorías
        return view('menuUser.mostrarP', ['productos' => $productos]);
    }

    public function create()
    {
        // Mostrar el formulario para crear un nuevo producto
        return view('admin.productos.crearProducto');
    }

    public function store(Request $request)
    {
        // Validación de datos
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'precio_unitario' => 'required|numeric|min:0',
            'categoria' => 'required|string|max:255',
            'unidades' => 'required|integer|min:0',
            // Agrega más validaciones según sea necesario
        ]);
    
        // Crear un nuevo producto en la base de datos
        ProductoModel::create([
            'nombre' => $request->input('nombre'),
            'descripcion' => $request->input('descripcion'),
            'precio_unitario' => $request->input('precio_unitario'),
            'categoria' => $request->input('categoria'),
            'unidades' => $request->input('unidades'),
            // Agrega más campos según sea necesario
        ]);
    
        // Redirigir a la lista de productos con un mensaje de éxito
        return redirect()->route('admin.productos.index')->with('success', 'Producto creado exitosamente.');
    }
    

    public function edit($id)
    {
        // Buscar el producto por su ID
        $producto = ProductoModel::findOrFail($id);

        // Mostrar el formulario de edición con los datos del producto
        return view('admin.productos.editarProducto', ['producto' => $producto]);
    }

    public function destroy($id)
    {
        // Buscar el producto por ID
        $producto = ProductoModel::find($id);

        // Verificar si el producto existe

        // Eliminar el producto
        $producto->delete();

        // Redirigir a la lista de productos con un mensaje de éxito
        return redirect()->route('admin.productos.index')->with('success', 'Producto eliminado exitosamente.');
    }

    public function update(Request $request, $id)
    {
        // Validación de datos
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'precio_unitario' => 'required|numeric|min:0',
            'categoria' => 'required|string|max:255',
            'unidades' => 'required|integer|min:0',
            // Agrega más validaciones según sea necesario
        ]);
    
        // Buscar el producto por ID
        $producto = ProductoModel::findOrFail($id);
    
        // Actualizar los campos del producto
        $producto->update([
            'nombre' => $request->input('nombre'),
            'descripcion' => $request->input('descripcion'),
            'precio_unitario' => $request->input('precio_unitario'),
            'categoria' => $request->input('categoria'),
            'unidades' => $request->input('unidades'),
            // Agrega más campos según sea necesario
        ]);
    
        // Redirigir a la lista de productos con un mensaje de éxito
        return redirect()->route('admin.productos.index')->with('success', 'Producto actualizado exitosamente.');
    }

    public function show($id)
    {
        // Buscar el producto por ID en la base de datos
        $producto = ProductoModel::find($id);

        // Verificar si el producto existe
        if (!$producto) {
            return redirect()->route('admin.productos.index')->with('error', 'Producto no encontrado');
        }

        // Puedes pasar el producto a la vista correspondiente
        return view('admin.productos.mostrar', ['producto' => $producto]);
    }

}
    


