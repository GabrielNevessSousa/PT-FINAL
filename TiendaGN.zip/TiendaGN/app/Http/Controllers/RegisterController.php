<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User; // Asegúrate de importar el modelo User si no lo has hecho

class RegisterController extends Controller
{
    public function index()
    {
        return view('login.register');
    }

    public function store(Request $request)
    {
        // Validación de datos
        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required',
            'nick' => 'required',
            'apellido' => 'required',
            'password' => 'required|',
            'fecha_nascimiento' => 'required|string',
            'dni' => 'required|string',
            'role' => 'required|in:usuario,administrador',
        ]);
       

        // Crear un nuevo usuario en la base de datos
        $user = new User([
            'nombre' => $request->input('nombre'),
            'email' => $request->input('email'),
            'apellido' => $request->input('apellido'),
            'nick' => $request->input('nick'),
            'fecha_nascimiento' => $request->input('fecha_nascimiento'),
            'dni' => $request->input('dni'),
            'password' => $request->input('password'),
            'role' => $request->input('role'),
        ]);

      

        $user->save();

        return redirect()->route('login.index')->with('success', 'Registro exitoso. Por favor, inicia sesión.');
    }

}

