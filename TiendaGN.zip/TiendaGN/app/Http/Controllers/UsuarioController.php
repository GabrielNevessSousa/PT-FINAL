<?php
// UsuarioController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UsuarioController extends Controller
{
    public function index()
    {
        // Obtener todos los usuarios desde la base de datos
        $usuarios = User::all();

        // Retornar la vista con los usuarios
        return view('admin.usuarios.mostrar', ['usuarios' => $usuarios]);
    }

    public function create()
    {
        // Mostrar el formulario para crear un nuevo usuario
        return view('admin.usuarios.crearUsuario');
    }

    public function store(Request $request)
    {
        // Validación de datos y almacenamiento en la base de datos
        $request->validate([
            'nombre' => 'required|string',
            'apellido' => 'required|string',
            'fecha_nascimiento' => 'required|string',
            'dni' => 'required|string',
            'nick' => 'required|string|',
            'email' => 'required|',
            'password' => 'required|',
            'role' => 'required|string',
        ]);

        $user = new User();
        $user->nombre = $request->input('nombre');
        $user->apellido = $request->input('apellido');
        $user->nick = $request->input('nick');
        $user->email = $request->input('email');
        $user->dni = $request->input('dni');
        $user->fecha_nascimiento = $request->input('fecha_nascimiento');
        $user->password = bcrypt($request->input('password'));
        $user->role = $request->input('role');
        $user->save();

        return redirect()->route('admin.usuarios.index');
    }

    public function edit($id)
    {
        $usuario = User::findOrFail($id);

        return view('admin.usuarios.editarUsuario', ['usuario' => $usuario]);
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'string|max:255',
            'apellido' => 'string|max:255',
            'dni' => 'string|max:255',
            'fecha_nascimiento' => 'string|max:255',
            'role' => 'string',
            'password' => 'email|max:255',
            'nick' => 'string|max:255',
        ]);

        $usuario = User::findOrFail($id);

        $usuario->update([
            'nick' => $request->input('nick'),
            'email' => $request->input('email'),
            'apellido' => $request->input('apellido'),
            'password' => $request->input('contrasena'),
            'nombre' => $request->input('nombre'),
            'dni' => $request->input('dni'),
            'role' => $request->input('role'),

        ]);

        return redirect()->route('admin.usuarios.index')->with('success', 'Usuario actualizado exitosamente');
    }

    public function destroy($id)
    {
        // Buscar el usuario por ID y eliminarlo
        $usuario = User::findOrFail($id);
        $usuario->delete();

        // Redirigir o mostrar una vista después de eliminar el usuario
        return redirect()->route('admin.usuarios.index');
    }

}
